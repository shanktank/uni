#include <iostream>
#include <cstdlib>
#include "IntList.h"

using namespace std;

// ~IntList()
// Traverses the list using a ListNode pointer and delete each node until
// nodePtr points to a null node meaning it's the end of the list
IntList::~IntList()
{
	ListNode *nodePtr;
	ListNode *nextNode;

	nodePtr = head;

	while(nodePtr != NULL)
	{
		nextNode = nodePtr->next;
		delete nodePtr;
		nodePtr = nextNode;
	}
}

// appendNode(int val)
// Receives a value to append to Linked List
// Dynamically creates a new ListNode and assigns
// val to its value, points to NULL to indicate it's
// the last node on the list. Appends node to end of
// list using nodePtr.
void IntList::appendNode(int val)
{
	ListNode *newNode;
	ListNode *nodePtr;

	newNode = new ListNode;
	newNode->value = val;
	newNode->next = NULL;

	if(!head)
		head = newNode;
	else
	{
		nodePtr = head;
		while(nodePtr->next)
			nodePtr = nodePtr->next;
		nodePtr->next = newNode;
	}
}

// insertByPos(int num, int pos)
// Creates a node with value num at position in LinkedList pos
//
void IntList::insertByPos(int num, int pos)
{
	ListNode *newNode;
	ListNode *nodePtr;
	ListNode *previousNode = NULL;
	int x = 0;

	// Assigns nodePtr to head of list
	nodePtr = head;

	// Creates new node and assigns value to num
	newNode = new ListNode;
	newNode->value = num;

	// Moves nodePtr down list until x equals num so that we're
	// inserting new node at correct position
	while(x != pos && nodePtr != NULL)
	{
		previousNode = nodePtr;
		nodePtr = nodePtr->next;
		x++;
	}

	// If list was empty, create new node
	if(!head)
	{
		head = newNode;
		newNode->next = NULL;
	}
	else
	{
		// If assigning to first node
		if(previousNode == NULL)
		{
			head = newNode;
			newNode->next = nodePtr;
			previousNode = head;
		}
		// Else simply create new node
		else
		{
			previousNode->next = newNode;
			newNode->next = nodePtr;
			previousNode = previousNode->next;
		}
	}
}

// removeByVal(int num)
// Uses num to remove a value from list
// If value not found, nothing will be removed
void IntList::removeByVal(int num)
{
	ListNode *nodePtr;
	ListNode *previousNode;

	// If list is empty then exit function
	if(!head)
		return;

	// If first value is num then point nodePtr to next node,
	// delete head and set next node to head of list
	if(head->value == num)
	{
		nodePtr = head->next;
		delete head;
		head = nodePtr;
	}
	else
	{
		// Set nodePtr to head of list
		nodePtr = head;

		// Move through list looking for num
		while(nodePtr != NULL && nodePtr->value != num)
		{
			previousNode = nodePtr;
			nodePtr = nodePtr->next;
		}

		// If value found, delete node and recconnect list
		if(nodePtr)
		{
			previousNode->next = nodePtr->next;
			delete nodePtr;
		}
	}
}

// displayList()
// Traverse through list and print each value to screen
void IntList::displayList()
{
	ListNode *nodePtr;

	nodePtr = head;

	while(nodePtr)
	{
		cout << nodePtr->value << endl;
		nodePtr = nodePtr->next;
	}
}

// removeByPos(int pos)
// Passes pos to be used as position in LinkedList to be removed
void IntList::removeByPos(int pos)
{
	ListNode *nodePtr;
	ListNode *previousNode;
	int x = 0;

	// Set nodePtr to head of list
	nodePtr = head;

	// If position is 0 then delete head and relink List
	if(pos == 0)
	{
		nodePtr = head->next;
		delete head;
		head = nodePtr;
	}

	// Traverse through list until x = pos and therefor position
	// in list found
	while(x != pos && nodePtr != NULL)
	{
		previousNode = nodePtr;
		nodePtr = nodePtr->next;
		x++;

		// Once position is found, delete value and relink list
		if(x == pos)
		{
			previousNode->next = nodePtr->next;
			delete nodePtr;
		}
	}
}

// search(int val)
// Passes val to be searched for in list
int IntList::search(int val)
{
	int count;

	ListNode *nodePtr;

	// Set nodePtr to be next node and search for val until end of list
	for(nodePtr = head->next, count = 1; nodePtr != NULL; nodePtr = nodePtr->next, count++)
	{
		// If value is found then return position in LinkedList
		if(nodePtr->value == val)
			return count;
	}
	// If value is not found then return position -1
	return -1;
}
