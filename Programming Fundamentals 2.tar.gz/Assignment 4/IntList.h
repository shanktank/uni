// Specification file for the IntList class
#ifndef INTLIST_H
#define INTLIST_H

class IntList
{
private:
   // Declare a structure for the list
   struct ListNode
   {
      int value;
      struct ListNode *next;
   };

   ListNode *head;   // List head pointer

public:
   // Constructor
   IntList();

   // Copy constructor
   IntList(const IntList &);

   // Destructor
   ~IntList();

   // List operations
   void appendNode(int val);
   void removeByVal(int val);
   void displayList();
   void insertByPos(int val, int pos);
   void removeByPos(int pos);
   int search(int val);
};

#endif /* INTLIST_H_ */

IntList::IntList()
{
	head = NULL;
}

IntList::IntList(const IntList &)
{

}

IntList::~IntList()
{
	ListNode *nodePtr;
	ListNode *nextNode;

	nodePtr = head;

	while(nodePtr != NULL)
	{
		nextNode = nodePtr->next;
		delete nodePtr;
		nodePtr = nextNode;
	}
}

void IntList::appendNode(int val)
{
	ListNode *newNode;
	ListNode *nodePtr;

	newNode = new ListNode;
	newNode->value = val;
	newNode->next = NULL;

	if(!head)
		head = newNode;
	else
	{
		nodePtr = head;
		while(nodePtr->Next)
			nodePtr = nodePtr->next;
		nodePtr->next = newNode;
	}
}

void IntList::insertByPos(int num, int pos)
{
	ListNode *newNode;
	ListNode *nodePtr;
	ListNode *previousNode = NULL;

	newNode = new listNode;
	newNode->value = num;

	if(!head)
	{
		head = newNode;
		newNode->next = NULL;
	}
	else
	{
		nodePtr = head;
		previousNode = NULL;
		while(nodePtr != NULL && nodePtr->value < num)
		{
			previousNode = nodePtr;
			nodePtr = nodePtr->next;
		}
		if(previousNode == NULL)
		{
			head = newNode;
			newNode->next = nodePtr;
		}
		else
		{
			previousNode->next = newNode;
			newNode->next = nodePtr;
		}
	}
}

void removeByVal(int num)
{
	ListNode *nodePtr;
	ListNode *previousNode;

	if(!head)
		return;

	if(head->value == num)
	{
		nodePtr = head->next;
		delete head;
		head = nodePtr;
	}
	else
	{
		nodePtr = head;

		while(nodePtr != NULL && nodePtr->value != num)
		{
			previousNode = nodePtr;
			nodePtr = nodePtr->next;
		}

		if(nodePtr)
		{
			previousNode->next = nodePtr->next;
			delete nodePtr;
		}
	}
}
