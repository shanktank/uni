#include <iostream>
#include <string>
#include <fstream>
#include <stdlib.h>
#include <time.h>
#include <cstring>

/*
Written by Jared Pruett
Class 2308-251, professor Zong Ziliang
*/

using namespace std;

struct Song
{
    string title;
    string artist;
    int size;
};

int countArray(int);
int readInSongs(ifstream &, Song *, int);
void remove_a_song(int, Song *);
int show_playlist(Song *, int);
void cleanup(Song *, int);
int shuffle(Song *, int);
int exitProgram(Song *);

int actualSize = 0;

int main()
{
    int arraySize = 0;
    int mbsTotal = 0;
    int response;
    bool firstPass = false;

    ifstream sfile;
    sfile.open("input_song.txt");
    if(!sfile)
    {
        cout << "Music database not found." << endl;
        system("pause");
        return -1;
    }

    // Determinte the maximum size needed for the dynamic array.
    arraySize = countArray(arraySize);

    // Create our dynamic array.
    Song *ptr = new Song[arraySize];

    // Determine total number of megabytes at the same time array is populated.
    mbsTotal = readInSongs(sfile, ptr, mbsTotal);
    
    // Close our read in file.
    sfile.close();

    cout << "Welcome to My iPod!\nPlease choose your option:\n";
    cout << "1. Show the playlist\n2. Remove a song\n3. Cleanup my iPod\n";
    cout << "4. Shuffle the playlist\n5. Exit\n\n";
    
    cin >> response;

    // Begin the main program control
    do
    {
        if(firstPass) //Don't display Welcome message during main program.
        {
            cout << "\nPlease choose your option:\n";
            cout << "1. Show the playlist\n2. Remove a song\n";
            cout << "3. Cleanup my iPod\n4. Shuffle the playlist\n5. Exit\n\n";
            cin >> response;
        }
        switch(response)
        {
            case 1:
                show_playlist(ptr, arraySize);
                break;
            case 2:
                remove_a_song(arraySize, ptr);
                break;
            case 3:
                cleanup(ptr, arraySize);
                break;
            case 4:
                shuffle(ptr, arraySize);
                break;
            case 5:
                exitProgram(ptr);
                break;
            default:
                cout << "Input not recognized. Please type 1, 2, 3, 4 or 5.\n";
                cin >> response;
                break;
        }
    firstPass = true;
    }while(1 < 2);

    system("pause");
    return 0;
}

int readInSongs(ifstream &sfile, Song *ptr, int total)
{
	int count = 0;
	int x = 1;
    total = 0;
    string line;
    
    // Populate dynamic array. If total MBs exceeds 25, leave loop.
	while(!sfile.eof() && total <= 25)
    {
        // x will incriment every time a non-empty file is read in.
        while(x < 4)
        {
            getline(sfile, line);
            if(!line.empty())
            {
                if(x == 1)
                    ptr[count].title = line;
                if(x == 2)
                    ptr[count].artist = line;
                if(x == 3)
                {
                    ptr[count].size = atoi(line.c_str());
                    total += ptr[count].size;
                }
            x++;
            }
        }
        count++;
        x = 1;
    }
    
    // If MBs exceeded 25, remove last song from array.
    if(total > 25)
    {
        count--;
        ptr[count].title = "";
        ptr[count].artist = "";
        total -= ptr[count].size;
        ptr[count].size = 0;
    }
    // The actual number of songs in our array is how many times count passed
    actualSize = count;
    sfile.close();
    return total;
}

void remove_a_song(int size, Song *ptr)
{
    string songName;
    bool found = false;

    // Ignore trailer endline characters.
    cin.ignore();
    cout << "\nEnter the name of the song you would like to delete: ";
    getline(cin,songName);

    // Search through Song array for entered song.
    for(int x = 0; x < actualSize; x++)
    {
    	// If song is found, shift all following songs up.
    	if(ptr[x].title == songName)
        {
            while(x < actualSize - 1)
            {
                ptr[x] = ptr[x + 1];
                x++;
            }
            ptr[x].title = "";
            ptr[x].artist = "";
            ptr[x].size = 0;
            found = true;
        }
    }
    if(found)
    	cout << "\nSong deleted.\n";
    if(!found)
    {
        cout << "\nSong not found. No song deleted. ";
        cout << "Input is case-sensitive.\n";
    }
}

int show_playlist(Song *ptr, int aSize)
{
    cout << endl;
    bool found = false;
    
    // Display the current playlist along with artist and size.
    for(int x = 0; x < aSize; x++)
    {
        if(ptr[x].title != "")
        {
            cout << ptr[x].title << " by " << ptr[x].artist;
            cout << ". " << ptr[x].size << " MBs in size.\n";
        }
    }
    
    // If Song's first title element is empty then we have wiped the playlist.
    for(int x = 0; x < actualSize; x++)
    {
        if(ptr[x].title != "")
            found = true;
    }
    if(!found)
        cout << "Playlist is empty!\n";
}

int countArray(int aSize)
{
    string temp;

    ifstream sfile;
    sfile.open("input_song.txt");
    if(!sfile)
    {
        cout << "Music database not found." << endl;
        system("pause");
        return -1;
    }

    // Determine the size of the array we will need by counting number
    // of lines, ignoring empty lines, and dividing by 3 (we have three
    // members per array element).
    while(!sfile.eof())
    {
        getline(sfile, temp);
        if(!temp.empty())
            aSize++;
    }
    sfile.close();
    aSize = aSize / 3;
    return aSize;
}

void cleanup(Song *ptr, int aSize)
{
    // Set all titles, artists and sizes to nothing so that they're not
    // counted by the rest of our program and don't count toward max
    // memory capacity.
    for(int x = 0; x < aSize; x++)
    {
        ptr[x].title = "";
        ptr[x].artist = "";
        ptr[x].size = 0;
    }
    cout << "\nPlaylist cleared!\n";
}

int shuffle(Song *ptr, int aSize)
{
    int random;
    Song temp;
    bool found = false;

    // Shuffle our array elements around using a random number generator
    // and a temporary storage of type Song.
    for(int x = 0; x < actualSize; x++)
    {
        srand(time(NULL));
        random = rand() % actualSize;
        temp = ptr[x];
        ptr[x] = ptr[random];
        ptr[random] = temp;
    }
    
    // If the first Song array's title member isn't populated then we have
    // emptied array.
    for(int x = 0; x < actualSize; x++)
    {
        if(ptr[x].title != "")
            found = true;
    }
    if(found == true)
        cout << "\nSongs successfully shuffled!\n";
    else
        cout << "\nNo songs to shuffle.\n";
}

int exitProgram(Song *ptr)
{
    // Delete our pointer and set to to not point to anything.
    delete [] ptr;
    ptr = NULL;
    exit(0);
}
