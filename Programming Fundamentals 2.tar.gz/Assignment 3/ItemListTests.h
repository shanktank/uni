// include guard
#ifndef ITEM_LIST_TESTS_HEADER
#define ITEM_LIST_TESTS_HEADER

/*
  Name: ItemListTests.h
  Author: Carl Gregory
  Date: 04/09/11
  Revised by: Ziliang Zong on 03/05/12

  Description: 
  			   This is the main program header
				 it contains the named constant definitions
				 and function prototypes
				 some defined labels are for debugging purposes
*/

#include "ItemListClass.h"	// class definition (prototypes for methods)

// #define DEBUG
#define TEST_APPEND
#define TEST_INSERT
#define TEST_READ_FILE
#define TEST_INSERT_VAL
#define TEST_REMOVE_VAL

const int MAX_LIST_SIZE = 17;

void testAppend(ItemList &);
void testInsert(ItemList &);
void testReadFile(ItemList &);
void testInsertVal(ItemList &);
void testRemove(ItemList &);
void testBehead(ItemList &);
void testRemoveVal(ItemList &);

#endif
