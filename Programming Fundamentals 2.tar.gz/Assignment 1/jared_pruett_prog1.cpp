#include <iostream>
#include <string>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <cstring>

////////////////COMPILED IN BLOODSHED DEV-C++ VERSION 4.9.9.2///////////////////
////////////////USING DEFAULT COMPILER IN WINDOWS 7 ULTIMATE 64 BIT/////////////
////////////////Written by Jared Pruett/////////////////////////////////////////
////////////////CS2308 Section 251//////////////////////////////////////////////
////////////////Professor Zong Ziliang//////////////////////////////////////////

using namespace std;

int read_questions();
int read_answers();
int show_question();
int player_try();
int play_game();
int sort_score();

string question[50][5];                                                         
string playerName;                                                              
char playerTry;                                                               
char answer[50];                                                              
int questionAmount = 0;                                                        
int random = 0;                                                                
int x = 1;                                                                      
int points = 0;                                                                 
bool secondTry = false;                                                         
bool gameOver = false;                                                          
bool halfPoints = false;                                                        
bool alreadyHalved = false;                                                     
bool qSkipped = false;     
bool correct = false;                               

string hsNames[101];                                                            
int hsScores[101];     

int main(int argc, char *argv[])

{
    read_questions();
    
  	string temp_string;
  	if (argc != 3)                                                              
  	{
   	cout << "Files entered incorrectly." << endl;
  		system("pause");                                                        
  		return -1;                                                              
  	}
  	ifstream fin_q(argv[1]);                                                   
  	if(!fin_q)                                                                 
  	{
  		cout << "First file was not able to be opened." << endl;
  		system("pause");
  		return -1;                                                          
  	}
  	ifstream fin_a(argv[2]);                                                    
  	if(!fin_a)                                                                  
  	{
   	    cout << "Second file was not able to be opened." << endl;
  		system("pause");
  		return -1;                                                              
  	}
  	string fname = "questions_answers";                                         
  	fname += ".txt";                                                            
  	ofstream fout(fname.c_str(), ios:: app);                                    
  	if(!fout)                                                                   
  	{
  		cout << "Was not able to write to target file." << endl;
  		system("pause");
  		return -1;                                                              
  	}
  	
  	play_game();
  	
  	while (!fin_q.eof())                                                        
  	{
  		getline (fin_q, temp_string);                                           
  		fout << '\n' << temp_string;                                            
    }
  	fout << "Answers begin here: " << endl;
  	while (!fin_a.eof())                                                        
  	{
  		getline (fin_a, temp_string);                                           

  		fout << '\n' << temp_string;                                            
  	}
  	fout << '\n' << "Player|Points: " << playerName << '|' << points << '\n';
  	cout << "Records file has been updated.\n" << endl;
  	fin_q.close();                   
  	fin_a.close();
    fout.close();

    sort_score();
    
    cout << "Your total score was " << points << endl;
    cout << "The current high score is " << hsScores[0] << " by player " <<
        hsNames[0] << "." << endl << endl;

system("pause");
return 0;
}

int read_questions()
{
	int qaLoop = 0;                                                             
	int sLoop = 0;                                                              
	string line;                                                                

    ifstream qfile;                                                             
    qfile.open("questions.txt");                                                
    if(!ifstream("questions.txt"))                                              
    {
        cout << "Questions file not found." << endl << endl;                    
        return -1;                                                              
    }
    while(!qfile.eof())                                                         
    {
        for(int x = 0; x < 6; x++)
        {
            if(x > 4)                                                           
            {
                 sLoop++;                                                       
                 questionAmount++;                                              
            }
            getline(qfile,line);
            if(!line.empty())
            {
                question[sLoop][qaLoop] = line;                                 
                qaLoop++;                                                       
            }
            if(qaLoop > 4)                                                      
                qaLoop = 0;                                                     
            if(qfile.eof())                                                     
                x = 6;                                                          
        }
    }
    qfile.close();                                                              
    read_answers();                                                             
}

int read_answers()
{
    char ch;                                                                    
    int loop = 0;                                                               
  
    ifstream fin("answers.txt");                                                
    if(!ifstream("answers.txt"))                                                
    {
        cout << "Answers file not found." << endl << endl;                      
        return -1;                                                              
    }
    while(!fin.eof())
    {
        ch = fin.get();
        if(ch != '\n' && !fin.eof())                                            
        {
            answer[loop] = ch;                                                  
            loop++;                                                             
        }
    }
    fin.close();                                                                
    if(loop != questionAmount)                                                  
    {
        cout << "Error: Question amount does not match answer amount." << endl; 
        return -1;                                                              
    }
}

int show_question()
{
    if(!secondTry)                                                              
    {
        cout << question[random][0] << endl;                                    
        for(int x = 1; x < 5; x++)                                              
        {
            if(x == 1)                                                          

                cout << "A. ";                                                  
            if(x == 2)
                cout << "B. ";
            if(x == 3)
                cout << "C. ";
            if(x == 4)
                cout << "D. ";
            cout << question[random][x] << endl;                                
        }
    player_try();                                                               
    }
    else                                                                        
    {
        cout << endl << question[random][0] << endl;                            
        for(int x = 1; x < 5; x++)
        {
            if(playerTry != 'A' && x == 1)                                      
                cout << "A. " << question[random][x] << endl;
            if(playerTry != 'B' && x == 2)
                cout << "B. " << question[random][x] << endl;
            if(playerTry != 'C' && x == 3)
                cout << "C. " << question[random][x] << endl;
            if(playerTry != 'D' && x == 4)
                cout << "D. " << question[random][x] << endl;
        }
    }
}

int player_try()
{
    char tryAgain = '0';                                                              
    cout << "Enter your answer or type 'S' for skip: ";                         
    cin >> playerTry;                                                           
    playerTry = toupper(playerTry);                                             
    while(playerTry != 'A' && playerTry != 'B' && playerTry != 'C' &&           
        playerTry != 'D' && playerTry != 'S')
    {
        cout << "Incorrect character input. Type A, B, C, D or S: ";            
        cin >> playerTry;                                                       
        playerTry = toupper(playerTry);                                         
    }
    
    if(playerTry != 'S')                                                        
    {
        if(answer[random] == playerTry)                                         
        {
            cout << "Correct! ";                                                
            correct = true;                                                     
        }
        else if(!secondTry)                                                     
        {
            while(tryAgain != 'Y' && tryAgain != 'N' && tryAgain != 'S')        
            {
                secondTry = true;                                               
                if(!alreadyHalved)                                              
                {
                    halfPoints = true;                                          
                    alreadyHalved = true;                                       
                }
                cout << "Incorrect. Try again? Type Y or N: ";
                cin >> tryAgain;                                                
                tryAgain = toupper(tryAgain);                                   
                if(tryAgain == 'Y')                                             
                {
                    show_question();                                            
                    player_try();                                               
                }
                else if(tryAgain == 'N')                                        
                {
                    cout << "\nGame over." << endl << endl;
                    gameOver = true;                                            
                    return -1;                                                  
                }
                else                                                            
                    cout << "Character not recognized. Type Y or N.";           
            }
            secondTry = false;                                                  
        }
        else                                                                    
        {
            cout << "Incorrect! Game over. No points for you." << endl;         
            points = 0;                                                         
            gameOver = true;                                                    
        }
    }
    else                                                                        
    {
        cout << "Question skipped. " << endl;                                   
        qSkipped = true;                                                        
    }
}

int play_game()
{
    int counter = 0;                                                            
    int y = 1;                                                                  
    int quAsked[questionAmount];                                                
    bool firstPass = false;                                                     
 
    cout << "Enter your name: ";
    cin >> playerName;
    cout << endl;
    cout << "Hello, " << playerName << "!\n\nYou will be asked six questions. ";
    cout << "For every question you answer correctly,\nyour score will be ";
    cout << "multiplied by ten. If you answer incorrectly,\nyou may try again";
    cout << " but all your "; 
    cout << "future rewarded points will be cut by half.\nYou may skip any";
    cout << " amount of questions, but you will receive no points for ";
    cout << "that\nquestion. If you incorrectly answer the same question twice";
    cout << ",\nyou lose the game and get no points! Beginning game now.";
    cout << endl << endl;
    for(int x = 0; x < questionAmount; x++)                                     
        quAsked[x] = 0;
    while(counter < questionAmount && counter < 7 && !gameOver)                 
    {
        if(firstPass)
            cout << "Picking question..." << endl << endl;
        while(quAsked[random] == 1)                                             
        {
            srand(time(NULL));
            random = rand() % questionAmount;
        }
        quAsked[random] = 1;                                                    
        if(firstPass)                                                           
            show_question();                                                    
        counter++;                                                              
        if(firstPass && !qSkipped && correct == true)                           
        {
            if(halfPoints == true)                                              
                y = y * 5;                                                      
            else                                                                
                y = y * 10;                                                     
            points = points + y;                                                
            cout << "Your score: " << points << endl << endl;                   
        }
        if(qSkipped)                                                            
            cout << endl;                                                       
        if(qSkipped && counter == questionAmount)                               
            cout << "Game over." << endl << endl;                               
        qSkipped = false;                                                       
        firstPass = true;                                                       
        halfPoints = false;                                                     
        correct = false;                                                        
    }
}

int sort_score()
{
    int hsNum = 0;                                                              
    int a = 0;                                                                  
    int swap = 0;                                                               
    string stringSwap;                                                          
    bool swapped = false;       
                                                    
    ifstream fin("summary.txt");                                                
    if(!ifstream("summary.txt"))                                                
    {
        cout << "High scores file not found." << endl;                          
        return -1;                                                              
    }
    while(!fin.eof())                                                           
    {
        char name[21];                                                          
        char score[8];                                                          
        fin.getline(name, 21, '|');                                             
        fin.getline(score, 8);                                                  
        hsNames[x] = name;                                                      
        hsScores[x] = atoi(score);                                              
        x++;                                                                    
    }
    fin.close();                                                               
    
    ofstream fout("summary.txt");                                               
    hsNum = x;                                                                  
    x = 0;                                                                      
    hsNames[x] = playerName;                                                    
    hsScores[x] = points;      
                                                        
    do                                                                          
    {
        swapped = false;                                                        
        for(int b = 1; b < hsNum; b++)                                          
        {                                                                           
            if(hsScores[a] < hsScores[b])                                       
            {
                swap = hsScores[a];                                             
                hsScores[a] = hsScores[b];
                hsScores[b] = swap;
                stringSwap = hsNames[a];                                        
                hsNames[a] = hsNames[b];
                hsNames[b] = stringSwap;
                swapped = true;                                                 
            }
            a++;                                                                
        }
        a = 0;                                                                  
    }while(swapped == true);                                                    
    fout << hsNames[x] << "|" << hsScores[x] << '\n';                           

    do                                                                          
    {
        x++;                                                                    
        if(x < hsNum && x < 100)                                                
            fout << hsNames[x] << "|" << hsScores[x];                           
        if(x + 1 < hsNum && x < 99)                                             
            fout << '\n';
    }while(x < hsNum);                                                          
    fout.close();                                                               
}
