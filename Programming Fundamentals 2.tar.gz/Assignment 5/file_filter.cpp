/* Dynamic Stacks and Queues by Jared Pruett						 *
 * Zong Ziliang 2308-251 Foundations of Computer Science II			 *
 * Due April 30, 2012. Written April 13 - April 27					 *
 * Reads from input.txt (required text) into dynamic stack and queue *
 * Outputs into two different output files, reversed or capitalized  */

#include <iostream>
#include <fstream>
#include "DynQueue.h"
using namespace std;

int main()
{
	char ch;

	DynQueue<char> queue; // Creates dynamic queue with type casting of char

	ifstream input;
	input.open("input.txt");
	if(!input)
	{
	    cout << "Input file not found." << endl;
	    return -1;
    }

	input.get(ch);

    while(!input.eof())
	{
	    queue.enQueue(ch);
	    input.get(ch);
	}

    input.close();

	ofstream output;
    output.open("output_filter.txt");
    if(!output)
    {
	    cout << "Output file was not found and could not be created." << endl;
	    return -1;
    }

	while(!queue.isEmpty())
	{
        queue.deQueue(ch);
	    ch = toupper(ch);
	    output.put(ch);
	}
	
	cout << "Ouput file created." << endl;

    output.close();

	return 0;
}
