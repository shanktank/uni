/* Dynamic Stacks and Queues by Jared Pruett						 *
 * Zong Ziliang 2308-251 Foundations of Computer Science II			 *
 * Due April 30, 2012. Written April 13 - April 27					 *
 * Reads from input.txt (required text) into dynamic stack and queue *
 * Outputs into two different output files, reversed or capitalized  */

#ifndef DYNQUEUE_H_
#define DYNQUEUE_H_

#include <iostream>

template <class T>
class DynQueue
{
	private:
    	struct QueueNode
    	{
    		T value;
    		QueueNode *next;
    		QueueNode(T val, QueueNode *nextp = NULL) // Struct constructor
    		{
    			value = val;
    			next = nextp;
    		}
    	};
    	QueueNode *front;
    	QueueNode *rear;
    	int numItems;

	public:
    	DynQueue();
    	~DynQueue();
    	void enQueue(T);
    	void deQueue(T &);
    	bool isEmpty();
    	bool isFull();
    	void clear();
};

/* DynQueue()
 * Dynamic queue class constructor
 * Sets front and rear equal to null and number of items to 0 */
template <class T>
DynQueue<T>::DynQueue()
{
	front = NULL;
	rear = NULL;
	numItems = 0;
}

/* ~DynQueue()
 * Dynamic queue class destructor
 * Calls clear function to remove all values before destructing */
template <class T>
DynQueue<T>::~DynQueue()
{
	clear();
}

/* enQueue(T val)
 * If queue is empty, sets front and rear to new node
 * Else creates new queue node at rear and moves rear
 * Increments number of items in queue counter */
template <class T>
void DynQueue<T>::enQueue(T val)
{
	if(isEmpty())
		front = rear = new QueueNode(val);
    else
    {
    	rear->next =  new QueueNode(val);
	    rear = rear->next;
    }
    numItems++;
}

/* deQueue(T &val)
 * Passes val to be used with pointers in removing value from queue
 * Checks to see if list is empty, if not, dequeues front and moves
 * queue back into order and deletes temp value
 * Decrements number of items in queue counter */
template <class T>
void DynQueue<T>::deQueue(T &val)
{
	QueueNode *temp;

    if(isEmpty())
    {
        exit(1);
    }
    else
    {
        val = front->value;
        temp = front;
        front = front->next;
        delete temp;
        numItems--;
    }
}

/* isEmpty()
 * Looks to see if numItems is not 0
 * if not, queue is not empty */
template <class T>
bool DynQueue<T>::isEmpty()
{
	if(numItems)
		return false;
    else
    	return true;
}

/* clear()
 * Dequeues all values until list is found to be empty */
template <class T>
void DynQueue<T>::clear()
{
	T value;

	while(!isEmpty())
		deQueue(value);
}

#endif
