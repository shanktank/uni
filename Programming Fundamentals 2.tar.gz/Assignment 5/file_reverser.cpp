/* Dynamic Stacks and Queues by Jared Pruett						 *
 * Zong Ziliang 2308-251 Foundations of Computer Science II			 *
 * Due April 30, 2012. Written April 13 - April 27					 *
 * Reads from input.txt (required text) into dynamic stack and queue *
 * Outputs into two different output files, reversed or capitalized  */

#include <iostream>
#include <fstream>
#include "DynStack.h"
using namespace std;

int main()
{
	char ch;

	DynStack<char> stack; // Creates dynamic stack with type casting of char

	ifstream input;
	input.open("input.txt");
	if(!input)
	{
        cout << "Input file not found." << endl;
        return -1;
    }

	input.get(ch);

	while(!input.eof())
	{
	    stack.push(ch);
		input.get(ch);
	}

    input.close();

	ofstream output;
	output.open("output_reverse.txt");
	if(!output)
	{
	    cout << "Output file was not found and could not be created." << endl;
	    return -1;
    }

	while(!stack.isEmpty())
	{
        stack.pop(ch);
		output.put(ch);
	}
	
	cout << "Ouput file created." << endl;

    output.close();

	return 0;
}
