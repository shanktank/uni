/* Dynamic Stacks and Queues by Jared Pruett						 *
 * Zong Ziliang 2308-251 Foundations of Computer Science II			 *
 * Due April 30, 2012. Written April 13 - April 27					 *
 * Reads from input.txt (required text) into dynamic stack and queue *
 * Outputs into two different output files, reversed or capitalized  */

#ifndef DYNSTACK_H_
#define DYNSTACK_H_

#include <iostream>

template <class T>
class DynStack
{
	private:
		struct StackNode
		{
			T value;
			StackNode *next;
			StackNode(T val, StackNode *nextP) // Struct constructor
			{
				value = val;
				next = nextP;
			}
		};
		StackNode *top;

	public:
		DynStack()
		{
			top = NULL;
		}
		void push(T);
		void pop(T &);
		bool isEmpty();
};

/* push(T val)
 * Passes val to be used as value for new stack node
 * Creates new stack node using my struct constructor */
template <class T>
void DynStack<T>::push(T val)
{
    top = new StackNode(val, top);
}

/* pop(T &val)
 * Passes location of val to be used with points to remove a node
 * Checks to see if stack is empty, if not, pops value */
template <class T>
void DynStack<T>::pop(T &val)
{
    StackNode *temp;

    if (!val)
    {
        return;
    }
    else
    {
        val = top->value;
        temp = top;
        top = top->next;
        delete temp;
    }
}

/* isEmpty()
 * Checks to see if top points to anything
 * If top points to something, list is not empty */
template <class T>
bool DynStack<T>::isEmpty()
{
    if (!top)
        return true;
    else
    	return false;
}

#endif
