#!/bin/bash

# Main menu function
print_menu()
{ 
    echo "Database($db_file) Size: ${#lines[@]}"
    echo
    echo "(a) Find a record"
    echo "(b) Add a new record"
    echo "(c) Update a record"
    echo "(d) Remove a record"
    echo "(e) Quit"
    echo
}

selection_parse()
{
   # Prompt user for choice
   read -p "> " menuOption
   # Call appropriate function based on input
   case "$menuOption" in
       a|A)
           find_entry_in_database
           ;;
       b|B)
           add_entry_in_database
           ;;
       c|C)
           update_entry_in_database
           ;;
       d|D)
           remove_entry_in_database
           ;;
       e|E)
           exit 0
           ;;
       # if not a valid option, prompt again
       *)
           echo "Invalid option, please choose again:"
           selection_parse
           ;;
   esac
}

main()
{
    echo "Welcome, please select in the following menu:"
    echo

    menuOption=""

    while [ 1 ]; do
        print_menu
        selection_parse
    done
}

# Function to update entry in database


########### Unitility Functions ############

# prompt user for search criteria, save
# postion of field to be searched in search_criteria_index
# value of that field in search_criteria_value
get_search_criteria()
{
   echo "search criteria?"
   echo "(0) Name"
   echo "(1) Address"
   echo "(2) Phone Number"
   echo "(3) Email"

   while [ 1 ]; do
       # Prompt user for choice
       read -p "> " search_criteria_index

       case "$search_criteria_index" in
           0)
               echo "enter name:"
               ;;
           1)
               echo "enter address:"
               ;;
           2)
               echo "enter phone number:"
               ;;
           3)
               echo "enter email:"
               ;;
           *)
               echo "invalid criteria, please choose from 0-3."
               continue
               ;;
       esac
        read -p "> " search_criteria_value
        break
    done
}


# takes search criteria, save matching entries's row index to found_entries
find_entry_then()
{
    # $1 is the field index
    # $2 is the field value
    found_entries=()
    
    for i in ${!lines[@]}; do
        # $i has the index, ${lines[$i]} has the value
        local IFS=":"
        fields=(${lines[($i)]})
        
        if [[ ${fields[$search_criteria_index]} == *$search_criteria_value* ]]; then
            found_entries+=($i)
        fi
    done
}

# save the in-memory db to disk
save_to_database()
{
    local IFS=$'\n'
    
    echo "${lines[*]}" > $db_file
    lines=($(cat "$db_file"))
}

# in case multiple matches are found, ask user to select one
select_one_if_necessary()
{
    selected_one=0

    if [[ "${#found_entries[*]}" -gt 1 ]]; then
        echo "Multiple entries found, which one to operate on?"

        for i in ${!found_entries[@]}; do
            echo "$i: ${lines[${found_entries[$i]}]}"
        done

        read -p "> " selected_one

        results=${#found_entries[@]}
        while [ $selected_one -ge $results ]; do
            echo "Incorrect input."
            read -p "> " selected_one
        done
    fi
}

# reads a value and reject it if it contain illegal character
read_entry_field()
{
    # $1 has the name of the field
    read -p "$1: " $1
    while [[ ! -z $(echo "${!1}"|grep ':') ]]; do
        read -p "$1 can not contain the character ':', please re-enter:" $1
    done
}

########### Main DB Functions ############
find_entry_in_database()
{
    get_search_criteria
    find_entry_then

    echo
    echo "matching record(s): " ${#found_entries[*]}
    for entry in ${found_entries[@]}; do
        local IFS=':'
        values=(${lines[$entry]})

        echo name: ${values[0]}
        echo address: ${values[1]}
        echo number: ${values[2]}
        echo email: ${values[3]}
        echo

    done
    echo
}


add_entry_in_database()
{
    echo
    echo "adding a new entry. Please enter the following fields."
    read_entry_field name
    read_entry_field address
    read_entry_field number
    read_entry_field email
    echo
    lines+=("$name:$address:$number:$email")

    save_to_database
}

update_entry_in_database()
{
    get_search_criteria
    find_entry_then
    select_one_if_necessary
    echo "updating an entry, which field would you like to update?"
    local IFS=':'
    fields=(${lines[${found_entries[$selected_one]}]})
    name=${fields[0]}
    address=${fields[1]}
    phone=${fields[2]}
    email=${fields[3]}
    echo "(0) name       [$name]"
    echo "(1) address    [$address]"
    echo "(2) phone #    [$phone]"
    echo "(3) email      [$email]"
    read -p "> " choice
    echo "enter new value"
    case $choice in
       0)
           read_entry_field name
           ;;
       1)
           read_entry_field address
           ;;
       2)
           read_entry_field phone
           ;;
       3)
           read_entry_field email
           ;;
       *)
           echo "Invalid option"
           return
           ;;
    esac
    lines[${found_entries[$selected_one]}]="$name:$address:$phone:$email"
    local IFS=$'\n'
    save_to_database
}

remove_entry_in_database()
{
    get_search_criteria
    find_entry_then
    select_one_if_necessary

    local IFS=$'\n'
    unset lines[${found_entries[$selected_one]}]
    
    save_to_database
}


# global variables
db_file=$1                  # disk location of the db
found_entries=()            # result of a search
search_criteria_index=""    # indicates with field to search
search_criteria_value=""    # search value
selected_one=0              # one of many search result selected by user

# check db path
if [[ $# -ne 1 ]]; then
    echo "Usage:"
    echo "$0 database_path"
    exit 1
fi

# initial setup, read db file
IFS=$'\n' lines=($(cat "$db_file"))

main
